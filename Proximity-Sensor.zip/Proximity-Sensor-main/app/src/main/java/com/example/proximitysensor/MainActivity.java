package com.example.proximitysensor;

import android.app.Activity;

public class MainActivity extends Activity {
}
