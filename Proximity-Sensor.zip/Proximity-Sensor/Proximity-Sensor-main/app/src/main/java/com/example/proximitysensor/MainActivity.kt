package com.example.proximitysensor

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.PowerManager
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null
    private lateinit var powerManager: PowerManager
    private lateinit var wakeLock: PowerManager.WakeLock
    private lateinit var proximityStatusTextView: TextView
    private val proximityThreshold = 3.0f

    // onCreate() – Initial Setup
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable edge-to-edge display (modern UI style)
        enableEdgeToEdge()

        // Set layout file
        setContentView(R.layout.activity_main)

        // Handle system bar padding for edge-to-edge layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Connect TextView from XML layout
        proximityStatusTextView = findViewById(R.id.proximityStatus)

        // Initialize Sensor Manager
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        // Get default proximity sensor
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)

        // Initialize Power Manager
        powerManager = getSystemService(POWER_SERVICE) as PowerManager

        // Create WakeLock for controlling screen using proximity sensor
        wakeLock = powerManager.newWakeLock(
            PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK,
            "ProximityLock::WakeLock"
        )

        // Check if device has proximity sensor
        if (proximitySensor == null) {
            Toast.makeText(this, "Proximity sensor not available", Toast.LENGTH_LONG).show()
        }
    }


    // onResume() – Register Sensor

    override fun onResume() {
        super.onResume()

        // Register sensor listener when activity becomes active
        proximitySensor?.also { sensor ->
            sensorManager.registerListener(
                this,                          // SensorEventListener
                sensor,                        // Proximity sensor
                SensorManager.SENSOR_DELAY_NORMAL  // Normal delay
            )

            Toast.makeText(this, "Proximity Sensor Registered", Toast.LENGTH_SHORT).show()

        } ?: Toast.makeText(this, "Proximity Sensor Not Available", Toast.LENGTH_SHORT).show()
    }

    // onPause() Unregister Sensor
    override fun onPause() {
        super.onPause()

        // Unregister listener to save battery
        sensorManager.unregisterListener(this)

        // Safety: Release WakeLock if still held
        if (wakeLock.isHeld) {
            wakeLock.release()
        }
    }
    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            val proximityValue = it.values[0]
            var screenStatus = ""
            Log.d("ProximitySensor", "Proximity Value: $proximityValue")
            if (proximityValue <= proximityThreshold) {

                Log.d("Threshold", "Less than threshold")

                // Acquire WakeLock only if not already held
                if (!wakeLock.isHeld) {
                    wakeLock.acquire()  // Turns screen OFF
                    screenStatus = "Screen OFF (Threshold Reached)"

                    Toast.makeText(this, screenStatus, Toast.LENGTH_SHORT).show()

                    Log.d("Proximity", "Screen OFF")
                }

            } else {
                Log.d("Threshold", "Greater than threshold")
                if (wakeLock.isHeld) {
                    wakeLock.release()  // Turns screen ON
                    screenStatus = "Screen ON (Threshold Exceeded)"

                    Toast.makeText(this, screenStatus, Toast.LENGTH_SHORT).show()

                    Log.d("Proximity", "Screen ON")
                }
            }

            // Update UI
            proximityStatusTextView.text =
                "Proximity Value: $proximityValue\nScreen Status: $screenStatus"
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }
}