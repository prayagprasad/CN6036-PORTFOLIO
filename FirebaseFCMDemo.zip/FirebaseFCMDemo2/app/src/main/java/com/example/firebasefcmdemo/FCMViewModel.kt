package com.example.firebasefcmdemo

import android.util.Log
import androidx.lifecycle.ViewModel
import com.google.firebase.messaging.FirebaseMessaging

class FCMViewModel : ViewModel() {
    // Function to fetch the token [cite: 1748]
    fun getFCMToken(onTokenReceived: (String) -> Unit) {
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("FCM", "Fetching FCM token failed", task.exception)
                    return@addOnCompleteListener
                }
                val token = task.result
                onTokenReceived(token) // Pass token back to UI [cite: 1756]
                Log.d("FCM", "FCM Token: $token")
            }
    }
}