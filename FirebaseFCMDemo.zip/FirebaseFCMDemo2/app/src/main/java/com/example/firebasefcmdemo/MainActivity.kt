package com.example.firebasefcmdemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // super.onCreate must be called before setContent
        setContent {
            // LocalContext provides the context needed for permissions and token fetching
            val context = LocalContext.current
            // Calling the FCMScreen created in Step 3
            FCMScreen(viewModel = FCMViewModel(), context = context)
        }
    }
}